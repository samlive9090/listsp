
* What is LISTSP *

 - LISTSP is a free and open source (windows only) process / service / driver viewer.

 - Provides Basic Management of Processes, Services & Drivers

 - GUI + Command Line

 - Multiple Actions on Process, Service & Driver


* Requirements *

 - Windows XP Service Pack 2 or higher

 - Administrator Rights / Account

 - .Net Framework 4.0


* Executable Files Build Using .Net Framework 3.5 and .Net Framework 4.0 *

 - http://sf.net/p/listsp/files


* Files Inside LISTSP.zip *

 - LISTSP.exe  ==>  [ Size: 2.04 MB (2,147,328 bytes) ]

 - Interop.IWshRuntimeLibrary.dll  [ For Creating Shortcut(s) ]  ==>  [ Size: 36.5 KB (37,376 bytes) ]

 - Readme.txt

 - License (GPL-3.0).txt

 - ChangeLog.txt


* Direct Links For Downloading .Net Framework 3.5 :-

 --- (.Net Framework 3.5 Full Standalone Installer)

 ----- http://download.microsoft.com/download/6/0/f/60fc5854-3cb8-4892-b6db-bd4f42510f28/dotnetfx35.exe

 ------- OR

 --- (.Net Framework 3.5 Service Pack 1 (SP1) Full Standalone Installer)

 ----- http://download.microsoft.com/download/2/0/e/20e90413-712f-438c-988e-fdaa79a8ac3d/dotnetfx35.exe
